/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poefinal;

//importing the import statements that we will need for the code
import java.io.FileWriter; //saves the reports to a file
import java.io.IOException;//handles the error within the files
import java.util.ArrayList;//this stores the list of users together with messages
import java.util.Random;//allows users to ass random values 
import javax.swing.JOptionPane;//GUI pop up dialogs

//We define a class that contains the whole application, this is to understand what we're working with
class User {
    String name;
    String phoneNumber;
    String username;
    String password;
    //the strings that name/declare the values we're using
    User(String name, String phoneNumber, String username, String password) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
    }
    //this helps with displaying the users details
    public String toString() {
        return name + " (" + phoneNumber + password + username +")";
    }
}

public class POEFINAL {
    //this displays/store the users and messages
    static ArrayList<User> registeredUsers = new ArrayList<>();
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static Random rand = new Random();

    public static void main(String[] args) {
        //Welcoming the user to the application,by displaying the welcome
       JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
       
       //---REGISTERING the users first---
        User u = registerUser();
        registeredUsers.add(u);
        JOptionPane.showMessageDialog(null, "Registration is successful.\nUser: " + u);
       
        //LOGING in users using the registered credentials
        String loginUser = JOptionPane.showInputDialog("Please enter your username :");
        String loginPass = JOptionPane.showInputDialog("Please enter your password :");
        
         if (loginUser.equals(u.username) && loginPass.equals(u.password)) {
        JOptionPane.showMessageDialog(null, "Login is successful. Redirecting to QuickChat...");
    } else {
        JOptionPane.showMessageDialog(null, "Login failed, now exiting app.");
        return;
    }
    //----CONTINUING WITH THE REST OF THE PROGRAM----
        //All the headings we'll be using to classify the information
        populateMessages();
        displaySentMessages();
        displayLongestMessage();
        searchByMessageID("ID4");
        searchMessagesByRecipient("+27838884567");
        deleteMessageByHash("hash2");
        displayReport();
        saveReportToFile("sent_report.txt");
        runUnitTests();
        
    }
    //---REGISTERING THE USERS---
    static User registerUser() {
        String name = JOptionPane.showInputDialog("Enter your full name:");

        //1. The USERNAME of the users
        String username = "";
        //this validates the username
        boolean valid = false;
        while (!valid) {
            username = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
            //if the username is invalid, an error message will display and the loop will continue until code is finshed
            if (username.contains("_") && username.length() <= 5) {
                valid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username.");
            }
        }
        
        //2. The users to write their PASSWORDS
         String password = "";
        valid = false;
        while (!valid) {
            String registeredPassword = JOptionPane.showInputDialog(
                "Create a password (min 8 chars, 1 uppercase, 1 digit, 1 special character):"
            );
            //this case validates the password
            boolean passwordOK = registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
            if (!passwordOK) {
            //if the password is invalid, an error message must display and the loop will continue until code is finshed
                JOptionPane.showMessageDialog(null,
                    "Password must be at least 8 characters and include a capital letter, a number, and a special character.");
            } else {
                password = registeredPassword;
                valid = true;
            }
        }
        
        //3. The users to write their PHONE NUMBERS
         String phone = null;
        valid = false;
        while (!valid) {
            phone = JOptionPane.showInputDialog(
                "Enter phone number:\n- Start with +27\n- Length: 9 characters total\nExamples: +27834557986"
            );
            if (phone == null) {
                JOptionPane.showMessageDialog(null, "Phone cannot be empty.");
                continue;
            }
            //this case validates the phone number 
            boolean formatOk =
            // +27 followed by 9 digits => total 10
                (phone.startsWith("+27") && phone.substring(3).matches("\\d{9}"))
            // 0 followed by 9 digits => total 10
                || (phone.startsWith("0") && phone.substring(1).matches("\\d{9}")); 
            //if the phone number is incorrect, an error message must display and the loop will continue until code is finshed
            if (formatOk) {
                valid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid phone format.\nTry: +27XXXXXXXXX");
            }
        }
       
        return new User(name, phone, username, password);
    }
    //the populated messages
    static void populateMessages() {
        //----Test data Message 1---(SENT)
        sentMessages.add("Did you get the cake?");
        messageIDs.add("ID1");
        messageHashes.add("hash1");
        recipients.add("+27834557986");
        
        //---Test Data Message 2---(STORED)
        storedMessages.add("Where are you? You are late! I have asked you to be on time.");
        messageIDs.add("ID2");
        messageHashes.add("hash2");
        recipients.add("+27838884567");
        
        //---Test Data Message 3---(DISREGARDED)
        disregardedMessages.add("Yohoooo, I am at your gate.");
        messageIDs.add("ID3");
        messageHashes.add("hash3");
        recipients.add("+27834484567");
        
        //---Test Data Message 4---(SENT)
        sentMessages.add("It is dinner time!");
        messageIDs.add("ID4");
        messageHashes.add("hash4");
        recipients.add("0838884567");
        
        //---Test Data Message 5---(STORED)
        storedMessages.add("Ok, I am leaving without you.");
        messageIDs.add("ID5");
        messageHashes.add("hash5");
        recipients.add("+27838884567");
    }
    //---Displaying all the senders and recipient of all sent messages---
    static void displaySentMessages() {
        System.out.println("\nSENT MESSAGES:");
        for (int i = 0; i < sentMessages.size(); i++) {
            System.out.println("RECIPIENTS: " + recipients.get(i));
            System.out.println("MESSAGE: " + sentMessages.get(i));
        }
    }
    //---This is where the longest sent messages are sent---
    static void displayLongestMessage() {
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        System.out.println("\n---LONGEST MESSAGES---:");
        System.out.println(longest);
    }
    //---Here we search for the message ID and display the corresponding recipient and messages---
    static void searchByMessageID(String id) {
        System.out.println("\n---SEARCH BY MESSAGES ID---: " + id);
        int index = messageIDs.indexOf(id);
        if (index != -1) {
            System.out.println("Recipient: " + recipients.get(index));
            System.out.println("Message: " + getMessageByIndex(index));
        } else {
            System.out.println("Message not found.");
        }
    }
    //---Searching for all the messages sent to a particular recipient---
     static void searchMessagesByRecipient(String recipient) {
        System.out.println("\nMessages sent to: " + recipient);
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipient)) {
                System.out.println(getMessageByIndex(i));
            }
        }
    }
    //---Deleting a message using the message hash--- 
    static void deleteMessageByHash(String hash) {
        System.out.println("\nDeleting message with hash:" + hash);
        int index = messageHashes.indexOf(hash);
        if (index != -1 && index < storedMessages.size()) {
            String deleted = storedMessages.remove(index);
            System.out.println("Message: \"" + deleted + "\" successfully deleted.");
        } else {
            System.out.println("Message not found or already deleted.");
        }
    }
    //---Displaying a report that lists the full details of all the sent messages---
    static void displayReport() {
        System.out.println("\nFull Sent Message Report:");
        for (int i = 0; i < sentMessages.size(); i++) {
            System.out.println("Hash: " + messageHashes.get(i));
            System.out.println("Recipient: " + recipients.get(i));
            System.out.println("Message: " + sentMessages.get(i));
            
        }
    }
    //---Saving all the reports to a file---
     static void saveReportToFile(String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            for (int i = 0; i < sentMessages.size(); i++) {
                writer.write("Hash: " + messageHashes.get(i) + "\n");
                writer.write("Recipient: " + recipients.get(i) + "\n");
                writer.write("Message: " + sentMessages.get(i) + "\n");
               
            }
            System.out.println("Report saved to " + filename);
        } catch (IOException e) {
            System.out.println("Error saving report: " + e.getMessage());
        }
    }
    //---This is the index that checks different list, such as sentMessages, storedMessages, disregardedMessages.
     //depending onn the index, it returns the correct message string---
    static String getMessageByIndex(int index) {
        if (index < sentMessages.size()) return sentMessages.get(index);
        int storedIndex = index - sentMessages.size();
        if (storedIndex < storedMessages.size()) return storedMessages.get(storedIndex);
        int disregardIndex = storedIndex - storedMessages.size();
        if (disregardIndex < disregardedMessages.size()) return disregardedMessages.get(disregardIndex);
        return null;
    }
    
    //---The unit tests that have to be displayed on the console for the messages
    static void runUnitTests() {
        System.out.println("\n---RUNNING UNIT TESTS---");

        //Here we have the messages that are sent successfully
        System.out.println("TEST 1:Sent Messages");
        System.out.println(sentMessages.contains("Did you get the cake?"));
        System.out.println(sentMessages.contains("It is dinner time!"));

        //Here is the declaration of the long messages
        System.out.println("TEST 2:Longest Message");
        System.out.println("Expected: Where are you? You are late! I have asked you to be on time.");

        //Lastly these are the messages that need to be searched
        System.out.println("TEST 3:Search by ID");
        System.out.println("Expected ID: 0838884567");
    }
}




        
    

